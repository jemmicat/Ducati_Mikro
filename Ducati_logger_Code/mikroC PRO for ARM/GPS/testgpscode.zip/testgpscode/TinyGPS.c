/*
  TinyGPS - a small GPS library for Arduino providing basic NMEA parsing
  Copyright (C) 2008-9 Mikal Hart
  All rights reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/* 
   edited by Ken Worster 5/18/09
   converted function calls to C-style
   eliminated "millis()" functionality
   added #defines to replace bools, enums
*/

#include "TinyGPS.h"

#define _GPRMC_TERM   "GPRMC"
#define _GPGGA_TERM   "GPGGA"

void TinyGPS_init(TinyGPS* gps)
{

	gps->_time = GPS_INVALID_TIME;
	gps->_date = GPS_INVALID_DATE;
	gps->_latitude = GPS_INVALID_ANGLE;
	gps->_longitude = GPS_INVALID_ANGLE;
	gps->_altitude = GPS_INVALID_ALTITUDE;
	gps->_speed = GPS_INVALID_SPEED;
	gps->_course = GPS_INVALID_ANGLE;
	gps->_last_time_fix = GPS_INVALID_FIX_TIME;
	gps->_last_position_fix = GPS_INVALID_FIX_TIME;
	gps->_parity = 0;
	gps->_is_checksum_term = false;
	gps->_sentence_type = _GPS_SENTENCE_OTHER;
	gps->_term_number = 0;
	gps->_term_offset = 0;
	gps->_gps_data_good = false;
#ifndef _GPS_NO_STATS
	gps->_encoded_characters = 0;
	gps->_good_sentences = 0;
	gps->_failed_checksum = 0;
#endif

	gps->_term[0] = '\0';
}

//
// public methods
//

bool encode(TinyGPS* gps, char c)
{
  bool valid_sentence = false;

  ++gps->_encoded_characters;
  switch(c)
  {
  case ',': // term terminators
    gps->_parity ^= c;
  case '\r':
  case '\n':
  case '*':
    if (gps->_term_offset < sizeof(gps->_term))
    {
      gps->_term[gps->_term_offset] = 0;
      valid_sentence = term_complete(gps);
    }
    ++gps->_term_number;
    gps->_term_offset = 0;
    gps->_is_checksum_term = c == '*';
    return valid_sentence;

  case '$': // sentence begin
    gps->_term_number = gps->_term_offset = 0;
    gps->_parity = 0;
    gps->_sentence_type = _GPS_SENTENCE_OTHER;
    gps->_is_checksum_term = false;
    gps->_gps_data_good = false;
    return valid_sentence;
  }

  // ordinary characters
  if (gps->_term_offset < sizeof(gps->_term) - 1)
    gps->_term[gps->_term_offset++] = c;
  if (!gps->_is_checksum_term)
    gps->_parity ^= c;

  return valid_sentence;
}



#ifndef _GPS_NO_STATS
void stats(TinyGPS* gps, unsigned long *chars, unsigned short *sentences, unsigned short *failed_cs)
{
  if (chars) *chars = gps->_encoded_characters;
  if (sentences) *sentences = gps->_good_sentences;
  if (failed_cs) *failed_cs = gps->_failed_checksum;
}
#endif

//
// internal utilities
//
int from_hex(char a) 
{
  if (a >= 'A' && a <= 'F')
    return a - 'A' + 10;
  else if (a >= 'a' && a <= 'f')
    return a - 'a' + 10;
  else
    return a - '0';
}

unsigned long parse_decimal(TinyGPS* gps)
{
  char *p = gps->_term;
  bool isneg = *p == '-';
  if (isneg) ++p;
  unsigned long ret = 100UL * gpsatol(p);
  while (gpsisdigit(*p)) ++p;
  if (*p == '.')
  {
    if (gpsisdigit(p[1]))
    {
      ret += 10 * (p[1] - '0');
      if (gpsisdigit(p[2]))
        ret += p[2] - '0';
    }
  }
  return isneg ? -ret : ret;
}



unsigned long parse_degrees(TinyGPS* gps)
{
  char *p;
  unsigned long left = gpsatol(gps->_term);
  unsigned long tenk_minutes = (left % 100UL) * 10000UL;
  for (p=gps->_term; gpsisdigit(*p); ++p);
  if (*p == '.')
  {
    unsigned long mult = 1000;
    while (gpsisdigit(*++p))
    {
      tenk_minutes += mult * (*p - '0');
      mult /= 10;
    }
  }
  return (left / 100) * 100000 + tenk_minutes / 6;
}

// Processes a just-completed term
// Returns true if new sentence has just passed checksum test and is validated
bool term_complete(TinyGPS* gps)
{
  if (gps->_is_checksum_term)
  {
    byte checksum = 16 * from_hex(gps->_term[0]) + from_hex(gps->_term[1]);
    if (checksum == gps->_parity)
    {
      if (gps->_gps_data_good)
      {
#ifndef _GPS_NO_STATS
        ++gps->_good_sentences;
#endif
        gps->_last_time_fix = gps->_new_time_fix;
        gps->_last_position_fix = gps->_new_position_fix;

        switch(gps->_sentence_type)
        {
        case _GPS_SENTENCE_GPRMC:
          gps->_time      = gps->_new_time;
          gps->_date      = gps->_new_date;
          gps->_latitude  = gps->_new_latitude;
          gps->_longitude = gps->_new_longitude;
          gps->_speed     = gps->_new_speed;
          gps->_course    = gps->_new_course;
          break;
        case _GPS_SENTENCE_GPGGA:
          gps->_altitude  = gps->_new_altitude;
          gps->_time      = gps->_new_time;
          gps->_latitude  = gps->_new_latitude;
          gps->_longitude = gps->_new_longitude;
          break;
        }

        return true;
      }
    }

#ifndef _GPS_NO_STATS
    else
      ++gps->_failed_checksum;
#endif
    return false;
  }

  // the first term determines the sentence type
  if (gps->_term_number == 0)
  {
    if (!gpsstrcmp(gps->_term, _GPRMC_TERM))
      gps->_sentence_type = _GPS_SENTENCE_GPRMC;
    else if (!gpsstrcmp(gps->_term, _GPGGA_TERM))
      gps->_sentence_type = _GPS_SENTENCE_GPGGA;
    else
      gps->_sentence_type = _GPS_SENTENCE_OTHER;
    return false;
  }

  if (gps->_sentence_type != _GPS_SENTENCE_OTHER && gps->_term[0])
  switch((gps->_sentence_type == _GPS_SENTENCE_GPGGA ? 200 : 100) + gps->_term_number)
  {
    case 101: // Time in both sentences
    case 201:
      gps->_new_time = parse_decimal(gps);
      gps->_new_time_fix = millis();
      break;
    case 102: // GPRMC validity
      gps->_gps_data_good = gps->_term[0] == 'A';
      break;
    case 103: // Latitude
    case 202:
      gps->_new_latitude = parse_degrees(gps);
      gps->_new_position_fix = millis();
      break;
    case 104: // N/S
    case 203:
      if (gps->_term[0] == 'S')
        gps->_new_latitude = -gps->_new_latitude;
      break;
    case 105: // Longitude
    case 204:
      gps->_new_longitude = parse_degrees(gps);
      break;
    case 106: // E/W
    case 205:
      if (gps->_term[0] == 'W')
        gps->_new_longitude = -gps->_new_longitude;
      break;
    case 107: // Speed (GPRMC)
      gps->_new_speed = parse_decimal(gps);
      break;
    case 108: // Course (GPRMC)
      gps->_new_course = parse_decimal(gps);
      break;
    case 109: // Date (GPRMC)
      gps->_new_date = gpsatol(gps->_term);
      break;
    case 206: // Fix data (GPGGA)
      gps->_gps_data_good = gps->_term[0] > '0';
      break;
    case 209: // Altitude (GPGGA)
      gps->_new_altitude = parse_decimal(gps);
      break;
  }

  return false;
}

long gpsatol(const char *str)
{
  long ret = 0;
  while (gpsisdigit(*str))
    ret = 10 * ret + *str++ - '0';
  return ret;
}

int gpsstrcmp(const char *str1, const char *str2)
{
  while (*str1 && *str1 == *str2)
    ++str1, ++str2;
  return *str1;
}

unsigned long millis()
{
	return 0;
}
