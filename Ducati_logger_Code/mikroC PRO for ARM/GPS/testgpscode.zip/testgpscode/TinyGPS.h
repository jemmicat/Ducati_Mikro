#ifndef TNY_GPS_H
#define TNY_GPS_H

/*
  TinyGPS - a small GPS library for Arduino providing basic NMEA parsing
  Copyright (C) 2008-9 Mikal Hart
  All rights reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/*
  edited by Ken Worster 5/18/09
  converted function calls to C-style
  eliminated "millis()" functionality
  added #defines to replace bools, enums
*/

#define _GPS_VERSION 9 // software version of this library
#define _GPS_MPH_PER_KNOT 1.15077945
#define _GPS_MPS_PER_KNOT 0.51444444
#define _GPS_KMPH_PER_KNOT 1.852
#define _GPS_MILES_PER_METER 0.00062137112
#define _GPS_KM_PER_METER 0.001
//#define _GPS_NO_STATS

#define GPS_INVALID_AGE 0xFFFFFFFF
#define GPS_INVALID_ANGLE 999999999
#define GPS_INVALID_ALTITUDE 999999999
#define GPS_INVALID_DATE 0
#define GPS_INVALID_TIME 0xFFFFFFFF
#define GPS_INVALID_SPEED 999999999
#define GPS_INVALID_FIX_TIME 0xFFFFFFFF

#define _GPS_SENTENCE_GPGGA 1 
#define _GPS_SENTENCE_GPRMC 2
#define _GPS_SENTENCE_OTHER 3


typedef unsigned char byte;
typedef unsigned int bool;
#define true 1;
#define false 0;

typedef struct 
{
    
    // properties
    unsigned long _time, _new_time;
    unsigned long _date, _new_date;
    long _latitude, _new_latitude;
    long _longitude, _new_longitude;
    long _altitude, _new_altitude;
    unsigned long  _speed, _new_speed;
    unsigned long  _course, _new_course;

    unsigned long _last_time_fix, _new_time_fix;
    unsigned long _last_position_fix, _new_position_fix;

    // parsing state variables
    byte _parity;
    bool _is_checksum_term;
    char _term[15];
    byte _sentence_type;
    byte _term_number;
    byte _term_offset;
    bool _gps_data_good;

#ifndef _GPS_NO_STATS
    // statistics
    unsigned long _encoded_characters;
    unsigned short _good_sentences;
    unsigned short _failed_checksum;
    unsigned short _passed_checksum;
#endif

} TinyGPS;

void TinyGPS_init(TinyGPS* gps);

bool encode(TinyGPS* gps, char c); // process one character received from GPS

unsigned long millis();

//TinyGPS &operator << (char c) {encode(c); return *this;}
    
// lat/long in hundred thousandths of a degree and age of fix in milliseconds
inline void get_position(TinyGPS* gps, long *latitude, long *longitude, unsigned long *fix_age)
{
  if (latitude) *latitude = gps->_latitude;
  if (longitude) *longitude = gps->_longitude;
  if (fix_age) *fix_age = gps->_last_position_fix == GPS_INVALID_FIX_TIME ? 
    GPS_INVALID_AGE : millis() - gps->_last_position_fix;
}

// date as ddmmyy, time as hhmmsscc, and age in milliseconds
inline void get_datetime(TinyGPS* gps, unsigned long *date, unsigned long *time, unsigned long *fix_age)
{
  if (date) *date = gps->_date;
  if (time) *time = gps->_time;
  if (fix_age) *fix_age = gps->_last_time_fix == GPS_INVALID_FIX_TIME ? 
    GPS_INVALID_AGE : millis() - gps->_last_time_fix;
}

// signed altitude in centimeters (from GPGGA sentence)
inline long altitude(TinyGPS* gps) { return gps->_altitude; }

// course in last full GPRMC sentence in 100th of a degree
inline unsigned long course(TinyGPS* gps) { return gps->_course; }
    
// speed in last full GPRMC sentence in 100ths of a knot
inline unsigned long speed(TinyGPS* gps) { return gps->_speed; }

#ifndef _GPS_NO_STATS
    void stats(TinyGPS* gps, unsigned long *chars, unsigned short *good_sentences, unsigned short *failed_cs);
#endif

inline void f_get_position(TinyGPS* gps, float *latitude, float *longitude, unsigned long *fix_age)
{
  long lat, lon;
  get_position(gps, &lat, &lon, fix_age);
  *latitude = lat / 100000.0;
  *longitude = lon / 100000.0;
}

inline void crack_datetime(TinyGPS* gps, int *year, byte *month, byte *day, 
  byte *hour, byte *minute, byte *second, byte *hundredths, unsigned long *fix_age)
{  
  unsigned long date, time;
  get_datetime(gps, &date, &time, fix_age);
  if (year) 
  {
    *year = date % 100;
    *year += *year > 80 ? 1900 : 2000;
  }
  if (month) *month = (date / 100) % 100;
  if (day) *day = date / 10000;
  if (hour) *hour = time / 1000000;
  if (minute) *minute = (time / 10000) % 100;
  if (second) *second = (time / 100) % 100;
  if (hundredths) *hundredths = time % 100;
}

inline float f_altitude(TinyGPS* gps)    { return altitude(gps) / 100.0; }
inline float f_course(TinyGPS* gps)      { return course(gps) / 100.0; }
inline float f_speed_knots(TinyGPS* gps) { return speed(gps) / 100.0; }
inline float f_speed_mph(TinyGPS* gps)   { return _GPS_MPH_PER_KNOT * f_speed_knots(gps); }
inline float f_speed_mps(TinyGPS* gps)   { return _GPS_MPS_PER_KNOT * f_speed_knots(gps); }
inline float f_speed_kmph(TinyGPS* gps) { return _GPS_KMPH_PER_KNOT * f_speed_knots(gps); }
static int library_version() { return _GPS_VERSION; }



// internal utilities
int from_hex(char a);

unsigned long parse_decimal(TinyGPS* gps);

unsigned long parse_degrees(TinyGPS* gps);
bool term_complete(TinyGPS* gps);

inline bool gpsisdigit(char c) { return c >= '0' && c <= '9'; }
long gpsatol(const char *str);
int gpsstrcmp(const char *str1, const char *str2);

#endif
