#include "lcd.h"
#include "TinyGPS.h"
#include <stdlib.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include "RingBuff.h"
#include "bitmasks.h"

#define USART_BAUDRATE 9600
#define BAUD_PRESCALE (((F_CPU / (USART_BAUDRATE * 16UL))) - 1)

RingBuff_t TestBuff;		// circular buffer for recieved characters
volatile char flags;		// 8 bits of flag data

#define char_received BIT(0)	// bit 0 signals a received character over serial port

int main(void)
{

	char tempBuffer[10];  // Used in printing lat/lon to LCD

	TinyGPS gps;	      // object containing all GPS information

	long latitude, longitude;	// Vars for holding lat/lon returned from 

	Buffer_Initialize(&TestBuff); // Init buffer (also clears/flushes/resets)

	UCSR1B |= (1 << RXEN) | (1 << TXEN);   // Turn on the transmission and reception circuitry
   	UCSR1C |= (1 << UCSZ0) | (1 << UCSZ1); // Use 8-bit character sizes

	UBRR1L = BAUD_PRESCALE; // Load lower 8-bits of the baud rate value into the low byte of the UBRR register
   	UBRR1H = (BAUD_PRESCALE >> 8); // Load upper 8-bits of the baud rate value into the high byte of the UBRR register 

	sei(); // Enable the Global Interrupt Enable flag so that interrupts can be processed

	UCSR1B |= (1 << RXCIE1);	// Enable serial reception interrupt

	TinyGPS_init(&gps);		// Needed before we can access GPS object

	lcd_init(LCD_DISP_ON);		// Needed before we display to LCD

	while(1)
	{

		if(bit_get(flags, char_received))	// We've received a character on the serial port
		{
			
			if(encode(&gps, Buffer_GetElement(&TestBuff)))	// GPS data has been updated
			{
				lcd_home();				// Cursor to upper left corner

				get_position(&gps, &latitude, &longitude, NULL); 	// Get current lat and long

				ltoa(latitude, tempBuffer, 10);				// Convert lat to string
	
				lcd_puts(tempBuffer);					// and display

				lcd_gotoxy(0,1);					// Next line

				ltoa(longitude, tempBuffer, 10);			// Convert longitude to string

				lcd_puts(tempBuffer);					// and display
	
			}

			if(!(Buffer_PeekElement(&TestBuff)))				// If receive buffer empty
			{
				bit_clear(flags, char_received);			// we shouldn't run encode() again
											// right now
			}

		}
	}

}

ISR(USART1_RX_vect)				// When we receive a character,
{	
	Buffer_StoreElement(&TestBuff, UDR1);	// store it in the circular receive buffer
	bit_set(flags, char_received);		// and set a flag to process it in the main loop
}
